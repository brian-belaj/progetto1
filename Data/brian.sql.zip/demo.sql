-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Creato il: Ott 19, 2021 alle 15:39
-- Versione del server: 8.0.25
-- Versione PHP: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `articles`
--

CREATE TABLE `articles` (
  `id` int NOT NULL,
  `immagine` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `testo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `articles`
--

INSERT INTO `articles` (`id`, `immagine`, `alt`, `titolo`, `testo`) VALUES
(1, '/images/immagini/IMG_4173.JPG', 'Immagine 1', 'Titolo1', 'Testo 1 eccetera'),
(2, '/images/immagini/IMG_4170.JPG', 'Immagine 2', 'Titolo2', 'Testo 2 eccetera'),
(3, '/images/immagini/IMG_4175.JPG', 'Immagine 3', 'Titolo 3', 'Testo 3 eccetera'),
(4, '/images/immagini/IMG_4155a.jpg', 'Immagine 4', 'Titolo 4', 'Testo 4 eccetera');

-- --------------------------------------------------------

--
-- Struttura della tabella `articles_photo`
--

CREATE TABLE `articles_photo` (
  `id` int NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `articles_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `articles_photo`
--

INSERT INTO `articles_photo` (`id`, `url`, `alt`, `articles_id`) VALUES
(1, '/images/carosello/_IMG_4139.JPG', '', 1),
(2, '/images/carosello/IMG_4139a.jpg', '', 2),
(3, '/images/carosello/IMG_4139b.JPG', '', 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `carousel`
--

CREATE TABLE `carousel` (
  `id` int NOT NULL,
  `img` varchar(255) NOT NULL,
  `alt_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ordine` int NOT NULL,
  `attivo` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `carousel`
--

INSERT INTO `carousel` (`id`, `img`, `alt_text`, `ordine`, `attivo`) VALUES
(1, './images/carosello/._IMG_4139.JPG', 'Immagine di prova numero 1', 1, b'1'),
(2, './images/carosello/IMG_4139a.jpg', 'Immagine di prova numero 2', 2, b'1'),
(3, './images/carosello/IMG_4139b.JPG', 'Immagine di prova numero 3', 3, b'1'),
(4, './images/carosello/IMG_4140.JPG', 'Immagine di prova numero 4', 4, b'1');

-- --------------------------------------------------------

--
-- Struttura della tabella `navigation_menu`
--

CREATE TABLE `navigation_menu` (
  `id` int NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt_text` varchar(255) DEFAULT NULL,
  `ordine` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `navigation_menu`
--

INSERT INTO `navigation_menu` (`id`, `titolo`, `url`, `alt_text`, `ordine`) VALUES
(1, 'Home', '/index.php', 'Home Page', 3),
(2, 'List', '/list.php', 'Elenco Prodotti', 1),
(3, 'Details', '/details.php', 'Dettaglio Prodotti', 2);

-- --------------------------------------------------------

--
-- Struttura della tabella `news`
--

CREATE TABLE `news` (
  `id` int NOT NULL,
  `immagine` varchar(255) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `testo` varchar(255) NOT NULL,
  `data_inserimento` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dump dei dati per la tabella `news`
--

INSERT INTO `news` (`id`, `immagine`, `alt`, `titolo`, `testo`, `data_inserimento`) VALUES
(1, 'IMG_4139.jpg', 'Immagine 1', 'Titolo 1', 'Testo 1 eccetera', '2021-10-14'),
(2, 'IMG_4140.JPG', 'Immagine2', 'Titolo 2', 'Testo 2 eccetera', '2021-10-15'),
(3, 'IMG_4155.jpg', 'Immagine3', 'Titolo 3', 'Testo 3 eccetera', '2021-10-16'),
(4, 'IMG_4170.JPG', 'Immagine 4', 'Titolo 4', 'Testo 4 eccetera', '2021-10-21');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `articles_photo`
--
ALTER TABLE `articles_photo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `article_photo_article` (`articles_id`);

--
-- Indici per le tabelle `carousel`
--
ALTER TABLE `carousel`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `navigation_menu`
--
ALTER TABLE `navigation_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `articles_photo`
--
ALTER TABLE `articles_photo`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT per la tabella `carousel`
--
ALTER TABLE `carousel`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `navigation_menu`
--
ALTER TABLE `navigation_menu`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `news`
--
ALTER TABLE `news`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `articles_photo`
--
ALTER TABLE `articles_photo`
  ADD CONSTRAINT `article_photo_article` FOREIGN KEY (`articles_id`) REFERENCES `articles` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

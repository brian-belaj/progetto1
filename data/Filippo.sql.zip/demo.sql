-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Generation Time: Oct 19, 2021 at 12:08 PM
-- Server version: 8.0.25
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `article_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `img` varchar(255) NOT NULL,
  `alt_text` varchar(255) NOT NULL,
  `ord` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `title`, `article_text`, `img`, `alt_text`, `ord`) VALUES
(1, 'titolo 1', 'titolo 1 perché ho fantasia da vendere', 'IMG_4175.jpg', 'gente che gioca a calcio', 1),
(2, 'titolo 2', 'titolo 2 perché ho fantasia da vendere', 'IMG_4175.jpg', 'gente che gioca a calcio', 2),
(3, 'titolo 3', 'titolo 3 perché ho fantasia da vendere', 'IMG_4175.jpg', 'gente che gioca a calcio', 3),
(4, 'titolo 4', 'titolo 4 perché ho fantasia da vendere', 'IMG_4175.jpg', 'gente che gioca a calcio', 4);

-- --------------------------------------------------------

--
-- Table structure for table `article_list`
--

CREATE TABLE `article_list` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `price` int NOT NULL,
  `category` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `article_list`
--

INSERT INTO `article_list` (`id`, `name`, `description`, `img`, `price`, `category`) VALUES
(1, 'Nome 1', 'Descrizione 1', '/images/immagini/IMG_4175.jpg', 10, 0),
(2, 'Nome 2', 'Descrizione 2', '/images/immagini/IMG_4175.jpg', 10, 0),
(3, 'Nome 3', 'Descrizione 3', '/images/immagini/IMG_4175.jpg', 10, 1),
(4, 'Nome 4', 'Descrizione 4', '/images/immagini/IMG_4175.jpg', 10, 1),
(5, 'Nome 5', 'Descrizione 5', '/images/immagini/IMG_4175.jpg', 10, 2),
(6, 'Nome 6', 'Descrizione 6', '/images/immagini/IMG_4175.jpg', 10, 2),
(7, 'Nome 7', 'Descrizione 7', '/images/immagini/IMG_4175.jpg', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `carousel`
--

CREATE TABLE `carousel` (
  `id` int NOT NULL,
  `img` varchar(255) NOT NULL,
  `alt_text` varchar(255) NOT NULL,
  `ordine` int NOT NULL,
  `active` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `carousel`
--

INSERT INTO `carousel` (`id`, `img`, `alt_text`, `ordine`, `active`) VALUES
(3, 'IMG_4139.jpg\r\n', 'è un portiere credo', 1, b'1'),
(4, 'IMG_4139a.jpg', 'forse è un altro portiere, ma probabilmente con i colori strampalati', 2, b'1'),
(5, 'IMG_4139b.jpg', 'credo sia ancora un portiere, ma forse maledetto da creature delle tenebre', 3, b'1'),
(6, 'IMG_4140.jpg', 'non ne ho idea', 4, b'1');

-- --------------------------------------------------------

--
-- Table structure for table `navigation_menu`
--

CREATE TABLE `navigation_menu` (
  `id` int NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `alt_text` varchar(255) NOT NULL,
  `ordine` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `navigation_menu`
--

INSERT INTO `navigation_menu` (`id`, `titolo`, `url`, `alt_text`, `ordine`) VALUES
(1, 'Home', '/index.php', 'Home Page', 1),
(2, 'List', '/list.php', 'Lista Prodotti', 2),
(3, 'Details', '/details.php', 'Dettagli prodotti', 3),
(4, 'pippo', '/pippo.php', 'pippotanto', 4),
(5, 'pippo 2', '/pippo_troppo.php', 'pippodavverotroppo', 4);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `news_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `date` datetime NOT NULL,
  `img` varchar(255) NOT NULL,
  `alt_text` varchar(255) NOT NULL,
  `ordine` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `news_text`, `date`, `img`, `alt_text`, `ordine`) VALUES
(1, 'titolo 1 ', 'testo 1', '2021-10-14 15:20:05', 'IMG_4155a.jpg', 'immagine 1, non so cosa ci sia raffigurato', 1),
(2, 'titolo 2 ', 'testo 2', '2021-10-14 15:20:05', 'IMG_4155.jpg', 'immagine 2, non so cosa ci sia raffigurato', 2),
(3, 'titolo 3 ', 'testo 3 molto impegnativo', '2021-10-14 15:20:05', 'IMG_4170.jpg', 'immagine 3, non so cosa ci sia raffigurato', 3),
(4, 'titolo 4 ', 'testo 4', '2021-10-14 15:20:05', 'IMG_4155a.jpg', 'immagine 4, non so cosa ci sia raffigurato', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `article_list`
--
ALTER TABLE `article_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carousel`
--
ALTER TABLE `carousel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `navigation_menu`
--
ALTER TABLE `navigation_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `article_list`
--
ALTER TABLE `article_list`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `carousel`
--
ALTER TABLE `carousel`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `navigation_menu`
--
ALTER TABLE `navigation_menu`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

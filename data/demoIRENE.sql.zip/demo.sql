-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Generation Time: Oct 19, 2021 at 12:06 PM
-- Server version: 8.0.25
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `id` int NOT NULL,
  `img` varchar(255) NOT NULL,
  `alt_text` varchar(255) NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `testo` varchar(255) NOT NULL,
  `ordine` int NOT NULL,
  `attivo` bit(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `img`, `alt_text`, `titolo`, `testo`, `ordine`, `attivo`) VALUES
(1, 'IMG_4175.JPG', 'imm01', 'Titolo primo', 'Testo testo testo 01', 1, b'0000000000000000000000000000000000000000000000000000000000000001'),
(2, 'IMG_4175.JPG', 'imm01', 'Titolo secondo', 'Testo testo testo 02', 2, b'0000000000000000000000000000000000000000000000000000000000000001'),
(3, 'IMG_4175.JPG', 'imm01', 'Titolo terzo', 'Testo testo testo 03', 3, b'0000000000000000000000000000000000000000000000000000000000000001'),
(4, 'IMG_4175.JPG', 'imm01', 'Titolo quarto', 'Testo testo testo 04', 3, b'0000000000000000000000000000000000000000000000000000000000000001');

-- --------------------------------------------------------

--
-- Table structure for table `article_prova`
--

CREATE TABLE `article_prova` (
  `id` int NOT NULL,
  `immagine` varchar(255) NOT NULL,
  `alt_text` varchar(255) NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `testo` varchar(255) NOT NULL,
  `ordine` varchar(64) NOT NULL,
  `attivo` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `article_prova`
--

INSERT INTO `article_prova` (`id`, `immagine`, `alt_text`, `titolo`, `testo`, `ordine`, `attivo`) VALUES
(1, '01.jpg', 'gatto', 'titolo ', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '1', 1),
(2, '02.jpg', 'gatto2', 'titolo titolo', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '2', 1),
(3, '03.jpg', 'gatto3', 'titolo', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '3', 1),
(4, '04.jpg', 'gatto4', 'titolo della scheda', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '4', 1);

-- --------------------------------------------------------

--
-- Table structure for table `carousel`
--

CREATE TABLE `carousel` (
  `id` int NOT NULL,
  `img` varchar(255) NOT NULL,
  `ordine` int NOT NULL,
  `attivo` bit(64) NOT NULL,
  `alt_text` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `carousel`
--

INSERT INTO `carousel` (`id`, `img`, `ordine`, `attivo`, `alt_text`) VALUES
(1, 'IMG_4140.JPG', 1, b'0000000000000000000000000000000000000000000000000000000000000001', 'imm1'),
(2, 'IMG_4140.JPG', 3, b'0000000000000000000000000000000000000000000000000000000000000001', 'imm1'),
(3, 'IMG_4140.JPG', 2, b'0000000000000000000000000000000000000000000000000000000000000001', 'imm2');

-- --------------------------------------------------------

--
-- Table structure for table `navigation_menu`
--

CREATE TABLE `navigation_menu` (
  `id` int NOT NULL,
  `titolo` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `alt_text` varchar(255) DEFAULT NULL,
  `ordine` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `navigation_menu`
--

INSERT INTO `navigation_menu` (`id`, `titolo`, `url`, `alt_text`, `ordine`) VALUES
(1, 'Home', '/index.php', 'Testo alternativo', 1),
(2, 'Lista', '/list.php', 'Testo 2', 2),
(5, 'Detail', '/details.php', 'testo 3', 3),
(6, 'Prova', '/prova.php', 'prova', 4);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int NOT NULL,
  `img` varchar(255) NOT NULL,
  `text_alt` varchar(255) NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `testo` varchar(255) NOT NULL,
  `data_news` date NOT NULL,
  `ordine` int NOT NULL,
  `attivo` bit(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `img`, `text_alt`, `titolo`, `testo`, `data_news`, `ordine`, `attivo`) VALUES
(1, 'IMG_4155a.jpg', 'imm01', 'primo titolo', 'TESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTO', '2021-10-01', 1, b'0000000000000000000000000000000000000000000000000000000000000001'),
(2, 'IMG_4155.jpg', 'imm02', 'secondo titolo', 'Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO ', '2021-10-02', 2, b'0000000000000000000000000000000000000000000000000000000000000001'),
(3, 'IMG_4155a.jpg', 'imm03', 'terzo titolo', 'TESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTOTESTO TESTO TESTO', '2021-10-03', 3, b'0000000000000000000000000000000000000000000000000000000000000001'),
(4, 'IMG_4155.jpg', 'imm04', 'quarto titolo', 'Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO Testo TESTO ', '2021-10-02', 4, b'0000000000000000000000000000000000000000000000000000000000000001');

-- --------------------------------------------------------

--
-- Table structure for table `news_prova`
--

CREATE TABLE `news_prova` (
  `id` int NOT NULL,
  `img` varchar(255) NOT NULL,
  `text_alt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `testo` varchar(255) NOT NULL,
  `data_news` date NOT NULL,
  `ordine` int NOT NULL,
  `attivo` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `news_prova`
--

INSERT INTO `news_prova` (`id`, `img`, `text_alt`, `titolo`, `testo`, `data_news`, `ordine`, `attivo`) VALUES
(1, '001.jpeg', 'immagine 001 ', 'TITOLO UNO!', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '2021-10-29', 1, 1),
(2, '002.jpeg', 'immagine 002', 'TITOLO DUE!', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '2021-10-30', 2, 1),
(3, '003.jpeg', 'immagine 003', 'TITOLO TRE!', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '2021-10-31', 3, 1),
(4, '001.jpeg', 'immagine 001 ', 'TITOLO QUATTRO', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '2021-11-01', 4, 1),
(5, '002.jpeg', 'immagine 002', 'TITOLO CINQUE!', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '2021-11-02', 5, 1),
(6, '003.jpeg', 'immagine 003', 'TITOLO SEI!', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '2021-11-03', 6, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `article_prova`
--
ALTER TABLE `article_prova`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carousel`
--
ALTER TABLE `carousel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `navigation_menu`
--
ALTER TABLE `navigation_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_prova`
--
ALTER TABLE `news_prova`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `article_prova`
--
ALTER TABLE `article_prova`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `carousel`
--
ALTER TABLE `carousel`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `navigation_menu`
--
ALTER TABLE `navigation_menu`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `news_prova`
--
ALTER TABLE `news_prova`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
